# مشروع تحويل الأموال (مصر ⇄ روسيا + USDT)

## طريقة التشغيل:
1. شغّل الخادم الخلفي:
   ```bash
   cd backend
   npm install
   node server.js
   ```

2. شغّل الواجهة الأمامية:
   ```bash
   cd frontend
   افتح index.html مباشرة في المتصفح
   ```
